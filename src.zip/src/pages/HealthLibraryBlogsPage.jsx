
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Search,
  ChevronDown,
  ArrowRight,
  BookOpen,
  SlidersHorizontal,
} from "lucide-react";


import { getBlogs } from "../api/blogsApi";
import { getSpecialities } from "../api/specialitiesApi";

import BlogCard from "../components/health-library/BlogCard";

import appointmentsWave from "../assets/appointments-wave.jpg";

const INITIAL_BLOGS = 16;
const LOAD_MORE_COUNT = 8;

export default function HealthLibraryBlogsPage() {
  const [search, setSearch] = useState("");
const [selectedSpeciality, setSelectedSpeciality] = useState("all");
const [visibleBlogs, setVisibleBlogs] = useState(INITIAL_BLOGS);

const [blogs, setBlogs] = useState([]);
const [loading, setLoading] = useState(true);
const [specialities, setSpecialities] = useState([]);
  

useEffect(() => {
  let active = true;

  const loadSpecialities = async () => {
    try {
      const response = await getSpecialities({
        is_active: 1,
        limit: 100,
      });

      const rows = Array.isArray(response)
        ? response
        : response?.rows ||
          response?.data?.rows ||
          response?.data ||
          [];

      if (active) {
        setSpecialities(
          rows.map((item) => ({
            id: item.id,
            name: item.name,
          }))
        );
      }
    } catch (error) {
      console.error("Unable to load specialities:", error);

      if (active) {
        setSpecialities([]);
      }
    }
  };

  loadSpecialities();

  return () => {
    active = false;
  };
}, []);


useEffect(() => {
  let active = true;

  const loadBlogs = async () => {
    try {
      setLoading(true);

      const data = await getBlogs({
        search: search.trim(),
        speciality_id:
          selectedSpeciality === "all"
            ? ""
            : selectedSpeciality,
      });

      if (active) {
        setBlogs(data);
      }
    } catch (error) {
      console.error("Unable to load blogs:", error);

      if (active) {
        setBlogs([]);
      }
    } finally {
      if (active) {
        setLoading(false);
      }
    }
  };

  loadBlogs();

  return () => {
    active = false;
  };
}, [search, selectedSpeciality]);

 useEffect(() => {
  setVisibleBlogs(INITIAL_BLOGS);
}, [search, selectedSpeciality]);

const displayedBlogs = blogs.slice(0, visibleBlogs);

  const handleLoadMore = () => {
    setVisibleBlogs((previous) => previous + LOAD_MORE_COUNT);
  };

 const clearFilters = () => {
  setSearch("");
  setSelectedSpeciality("all");
  setVisibleBlogs(INITIAL_BLOGS);
};

  return (
    <main className="min-h-screen bg-white">

      {/* BREADCRUMB */}
<nav
  aria-label="Breadcrumb"
  className="relative w-full overflow-hidden border-b border-[#dce5da] bg-cover bg-center"
  style={{
    backgroundImage: `url(${appointmentsWave})`,
  }}
>
  <div className="page-container relative z-10 mx-auto px-5 py-4 sm:px-8 lg:px-12">
    <ol className="flex items-center gap-2 overflow-x-auto whitespace-nowrap text-sm">
      <li>
        <Link
          to="/"
          className="font-semibold text-white drop-shadow-md transition-colors hover:text-[#E87744]"
        >
          Home
        </Link>
      </li>

      <li className="text-white/90 drop-shadow-md" aria-hidden="true">
        /
      </li>

      <li>
        <Link
          to="/health-library"
          className="font-semibold text-white drop-shadow-md transition-colors hover:text-[#E87744]"
        >
          Health Library
        </Link>
      </li>

      <li className="text-white/90 drop-shadow-md" aria-hidden="true">
        /
      </li>

      <li
        aria-current="page"
        className="font-bold text-white drop-shadow-md"
      >
        Blogs
      </li>
    </ol>
  </div>
</nav>
      

      {/* BLOGS MAIN CONTENT */}
      <section className="page-container px-5 py-14 sm:px-8 sm:py-16 lg:px-12 lg:py-20">

        {/* CENTER HEADING */}
        <div className="mx-auto mb-12 max-w-3xl text-center">

          <div className="mb-5 flex items-center justify-center gap-3">
            <span className="h-[2px] w-10 rounded-full bg-[#E87744]" />

            <span className="text-xs font-bold uppercase tracking-[3px] text-[#4F7359]">
              KIMS RENOVA HEALTH LIBRARY
            </span>

            <span className="h-[2px] w-10 rounded-full bg-[#E87744]" />
          </div>

          <h1 className="display-font text-3xl font-extrabold text-[#243528] sm:text-4xl lg:text-5xl">
            Health & Wellness Blogs
          </h1>

          <p className="mx-auto mt-3 max-w-2xl text-base leading-8 text-[#383938] sm:text-lg">
            Discover reliable information and helpful insights about
            cancer awareness, symptoms, diagnosis, treatments,
            prevention and survivorship.
          </p>

          {/* <div className="mx-auto mt-6 h-1 w-16 rounded-full bg-[#E87744]" /> */}
        </div>

        {/* SEARCH AND FILTER */}
        <div className="mx-auto mb-10 grid max-w-5xl grid-cols-1 gap-4 md:grid-cols-[1fr_280px]">

          {/* SEARCH */}
          <div
           className="flex min-h-[46px] items-center gap-3 rounded-xl border border-[#D4E0D6] bg-white px-5 shadow-sm transition focus-within:border-[#4F7359] focus-within:ring-2 focus-within:ring-[#4F7359]/10"
           >

            <Search
              size={21}
              className="shrink-0 text-[#4F7359]"
            />

            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search blogs and health articles..."
              aria-label="Search blogs"
              className="w-full bg-transparent text-base text-[#3D4A40] outline-none ring-0 focus:outline-none focus:ring-0 focus-visible:outline-none placeholder:text-slate-400"
              // className="w-full bg-transparent text-base text-[#3D4A40] outline-none placeholder:text-slate-400"
            />
          </div>

          {/* CATEGORY FILTER */}
          <div 
          className="relative flex min-h-[46px] items-center rounded-xl border border-[#D4E0D6] bg-white px-5 shadow-sm transition focus-within:border-[#4F7359]"
          >

            <SlidersHorizontal
              size={19}
              className="mr-3 shrink-0 text-[#4F7359]"
            />

            <select
  value={selectedSpeciality}
  onChange={(event) =>
    setSelectedSpeciality(event.target.value)
  }
  aria-label="Filter blogs by speciality"
  className="w-full appearance-none bg-transparent pr-7 text-base font-semibold text-[#3D4A40] outline-none ring-0 focus:outline-none focus:ring-0 focus-visible:outline-none"
  // className="w-full appearance-none bg-transparent pr-7 text-base font-semibold text-[#3D4A40] outline-none"
>
  <option value="all">All Specialities</option>

  {specialities.map((speciality) => (
    <option
      key={speciality.id}
      value={speciality.id}
    >
      {speciality.name}
    </option>
  ))}
</select>

            <ChevronDown
              size={18}
              className="pointer-events-none absolute right-5 text-[#4F7359]"
            />
          </div>
        </div>

        {/* RESULTS COUNT */}
        <div className="mb-7 flex flex-wrap items-center justify-between gap-3  pb-4">

          <p className="text-sm font-medium text-[#3D4A40] sm:text-base">
            Showing{" "}
            <span className="font-bold text-[#4F7359]">
              {displayedBlogs.length}
            </span>{" "}
            of{" "}
            <span className="font-bold text-[#4F7359]">
              {/* {filteredBlogs.length} */}
              {blogs.length}
            </span>{" "}
            articles
          </p>

            {(search || selectedSpeciality !== "all") && (
            <button
              type="button"
              onClick={clearFilters}
              className="text-sm font-bold text-[#E87744] transition hover:text-[#4F7359]"
            >
              Clear Filters
            </button>
          )}
        </div>

        {/* BLOG CARDS */}
        {/* {displayedBlogs.length > 0 ? ( */}
          {loading ? (
            <p className="rounded-xl bg-[#F6F9F6] p-8 text-center text-[#4F7359]">
              Loading blogs...
            </p>
          ) : displayedBlogs.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">

            {displayedBlogs.map((blog) => (
              <BlogCard
                key={blog.slug}
                blog={blog}
              />
            ))}

          </div>

        ) : (

          /* NO RESULTS */
          <div className="rounded-2xl border border-dashed border-[#D4E0D6] bg-[#F6F9F6] px-5 py-16 text-center">

            <BookOpen
              size={45}
              className="mx-auto text-[#4F7359]"
            />

            <h2 className="display-font mt-5 text-2xl font-bold text-[#243528]">
              No Blogs Found
            </h2>

            <p className="mt-3 text-base text-[#3D4A40]">
              Try another search term or select a different category.
            </p>

            <button
              type="button"
              onClick={clearFilters}
              className="mt-6 inline-flex items-center justify-center rounded-full bg-[#4F7359] px-7 py-3 text-sm font-bold text-white transition hover:bg-[#E87744]"
            >
              View All Blogs
            </button>

          </div>
        )}

        {/* LOAD MORE */}
        {/* {displayedBlogs.length < filteredBlogs.length && ( */}
        {displayedBlogs.length < blogs.length && (
          <div className="mt-14 text-center">

            <button
              type="button"
              onClick={handleLoadMore}
              className="inline-flex min-h-[52px] items-center justify-center gap-3 rounded-full bg-[#4F7359] px-9 py-3 text-base font-bold text-white shadow-md transition duration-300 hover:-translate-y-1 hover:bg-[#E87744] hover:shadow-lg"
            >
              Load More Blogs

              <ArrowRight size={19} />
            </button>

            <p className="mt-4 text-sm text-[#3D4A40]">
              Showing {displayedBlogs.length} of {blogs.length} blogs
              {/* Showing {displayedBlogs.length} of {filteredBlogs.length} blogs */}
            </p>

          </div>
        )}

        {/* ALL BLOGS VIEWED */}
        {blogs.length > 0 &&
          displayedBlogs.length === blogs.length && (
            <p className="mt-12 text-center text-sm font-semibold text-[#4F7359]">
              You have viewed all available blogs.
            </p>
          )}

      </section>
    </main>
  );
}





